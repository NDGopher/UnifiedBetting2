// pod_alert_extension/content.js - Firefox Version
// BASED ON YOUR WORKING VERSION THAT YOU PROVIDED
// Changes:
// 1. Ensure 'waitForEventId' correctly interfaces with 'background.js' for the SNIFFED Swordfish eventId.
// 2. Ensure 'processAlert' sends the CORRECT eventId in the payload to 'background.js'.
// 3. Added polling fallback to detect new rows that MutationObserver might miss.
// 4. Updated for Firefox WebExtensions API compatibility

(function() {
    console.log("POD Content Script (Firefox Version - v5 EventId Focus) Loaded:", new Date().toISOString());

    const processedAlerts = new Map(); 
    const FETCH_INTERVAL = 2000; // Your original value
    let lastFetchTime = 0;

    // Function to handle random page refreshes
    function setupRandomRefresh() {
        const getRandomTime = () => {
            // Random time between 20-30 minutes in milliseconds
            return Math.floor(Math.random() * (30 - 20 + 1) + 20) * 60 * 1000;
        };

        const scheduleNextRefresh = () => {
            const nextRefreshTime = getRandomTime();
            console.log(`[Auto-Refresh] Next refresh scheduled in ${nextRefreshTime/60000} minutes`);
            setTimeout(() => {
                console.log('[Auto-Refresh] Refreshing page...');
                window.location.reload();
            }, nextRefreshTime);
        };

        // Schedule the first refresh
        scheduleNextRefresh();
    }

    function waitForElement(selector, timeout = 15000, parentNode = document.body) {
        return new Promise((resolve) => {
            let element = parentNode.querySelector(selector);
            if (element) { resolve(element); return; }
            const observer = new MutationObserver((_, obs) => {
                element = parentNode.querySelector(selector);
                if (element) { obs.disconnect(); resolve(element); }
            });
            observer.observe(parentNode, { childList: true, subtree: true });
            setTimeout(() => {
                observer.disconnect();
                resolve(parentNode.querySelector(selector));
            }, timeout);
        });
    }

    function generateAlertHash(alertData) { // Your original
        return `${alertData["Home Team"]}-${alertData["Away Team"]}-${alertData["OldOdds"]}-${alertData["NewOdds"]}-${alertData["Bet"]}-${alertData["LineType"]}`;
    }

    function parseMatchString(matchStr) { // Your original
        try {
            const parts = matchStr.split('H:');
            if (parts.length < 2) return null;
            const timeDate = parts[0].trim();
            const timeDateParts = timeDate.split(' ');
            const time = timeDateParts[0] || "";
            const date = timeDateParts[1] || "";
            const remaining = parts[1].split('A:');
            if (remaining.length < 2) return null;
            const homeTeam = remaining[0].trim();
            let awayTeamAndLeague = remaining[1].trim();
            let league = "Unknown";
            let awayTeam = awayTeamAndLeague;

            const knownLeagues = ["NCAA", "NBA", "NHL", "MLB", "Copa Do Nordeste", "Brazil - Cup", "Qatar - Emir Cup", "Kenya - Premier League"]; // Added from your logs
            for (const knownLeague of knownLeagues) {
                // More robust check: ensure knownLeague is a whole word or at the end
                const regex = new RegExp(`\\b${knownLeague.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')}\\b`, 'i'); // Case insensitive, whole word
                const match = awayTeamAndLeague.match(regex);
                if (match) {
                    const index = match.index;
                    // Check if it makes sense as a league (e.g., often towards the end)
                    if (index > awayTeamAndLeague.length / 2 || awayTeamAndLeague.substring(index + knownLeague.length).trim().length < 5) {
                         league = awayTeamAndLeague.substring(index, index + knownLeague.length);
                         awayTeam = awayTeamAndLeague.substring(0, index).trim();
                         break;
                    }
                }
            }
            if (league === "Unknown") { // Fallback
                const lastDashIndex = awayTeamAndLeague.lastIndexOf(" - ");
                if (lastDashIndex !== -1 && lastDashIndex > 0) { // Ensure dash is not at the beginning
                    let potentialLeague = awayTeamAndLeague.substring(lastDashIndex + 3).trim();
                    let potentialTeam = awayTeamAndLeague.substring(0, lastDashIndex).trim();
                    // Basic heuristic: if "league" part is shorter or contains typical league words
                    if (potentialLeague.length < potentialTeam.length || potentialLeague.toLowerCase().includes("league") || potentialLeague.toLowerCase().includes("cup")) {
                        league = potentialLeague;
                        awayTeam = potentialTeam;
                    } else {
                        // Keep awayTeam as is, league remains Unknown or is part of awayTeam
                    }
                }
            }

            return { time, date, homeTeam, awayTeam, league };
        } catch (error) {
            console.error("Error parsing match string:", matchStr, error);
            return null;
        }
    }

    function extractAlertData(row) { // Your original (with slight robustification)
        try {
            const cells = row.querySelectorAll('td');
            if (cells.length < 7) {
                console.warn("Row has insufficient cells:", cells.length);
                return null;
            }

            const matchStr = cells[0]?.textContent?.trim() || "";
            const parsedMatch = parseMatchString(matchStr);
            if (!parsedMatch) {
                console.warn("Failed to parse match string:", matchStr);
                return null;
            }

            const alertData = {
                "Home Team": parsedMatch.homeTeam,
                "Away Team": parsedMatch.awayTeam,
                "League": parsedMatch.league,
                "Time": parsedMatch.time,
                "Date": parsedMatch.date,
                "OldOdds": cells[1]?.textContent?.trim() || "",
                "NewOdds": cells[2]?.textContent?.trim() || "",
                "Bet": cells[3]?.textContent?.trim() || "",
                "LineType": cells[4]?.textContent?.trim() || "",
                "AlertTime": cells[5]?.textContent?.trim() || "",
                "AlertType": cells[6]?.textContent?.trim() || ""
            };

            // Validation
            if (!alertData["Home Team"] || !alertData["Away Team"] || !alertData["OldOdds"] || !alertData["NewOdds"]) {
                console.warn("Missing required alert data:", alertData);
                return null;
            }

            return alertData;
        } catch (error) {
            console.error("Error extracting alert data:", error);
            return null;
        }
    }

    // Firefox-compatible message sending
    async function sendMessageToBackground(message) {
        try {
            return await browser.runtime.sendMessage(message);
        } catch (error) {
            console.error("Error sending message to background:", error);
            throw error;
        }
    }

    async function waitForSniffedEventId(clickTimestamp) {
        const maxWaitTime = 10000; // 10 seconds
        const checkInterval = 100; // Check every 100ms
        const startTime = Date.now();

        while (Date.now() - startTime < maxWaitTime) {
            try {
                const response = await sendMessageToBackground({ type: "getLatestSniffedEventDetails" });
                
                if (response && response.eventId && response.timestamp > clickTimestamp) {
                    console.log(`[Content] Found sniffed eventId: ${response.eventId} (timestamp: ${response.timestamp})`);
                    return response.eventId;
                }
                
                await new Promise(resolve => setTimeout(resolve, checkInterval));
            } catch (error) {
                console.error("[Content] Error checking for sniffed eventId:", error);
                await new Promise(resolve => setTimeout(resolve, checkInterval));
            }
        }
        
        console.warn("[Content] Timeout waiting for sniffed eventId");
        return null;
    }

    async function processAlert(row) {
        const alertData = extractAlertData(row);
        if (!alertData) {
            console.warn("[Content] Failed to extract alert data from row");
            return;
        }

        const alertHash = generateAlertHash(alertData);
        if (processedAlerts.has(alertHash)) {
            console.log("[Content] Alert already processed:", alertHash);
            return;
        }

        console.log("[Content] Processing new alert:", alertData);

        // Mark as processed immediately to prevent duplicate processing
        processedAlerts.set(alertHash, Date.now());

        // Simulate click to trigger eventId capture
        const clickTimestamp = Date.now();
        row.click();
        
        // Wait for the sniffed eventId
        const eventId = await waitForSniffedEventId(clickTimestamp);
        
        if (!eventId) {
            console.warn("[Content] No eventId captured for alert:", alertData);
            return;
        }

        // Prepare payload for Python backend
        const payload = {
            eventId: eventId,
            alertData: alertData,
            timestamp: Date.now(),
            url: window.location.href
        };

        console.log("[Content] Sending payload to Python:", payload);

        try {
            const response = await sendMessageToBackground({
                type: "forwardToPython",
                payload: payload
            });

            if (response && response.status === "success") {
                console.log("[Content] Successfully forwarded to Python:", response);
            } else {
                console.error("[Content] Failed to forward to Python:", response);
            }
        } catch (error) {
            console.error("[Content] Error forwarding to Python:", error);
        }
    }

    function processRow(row) {
        if (row.classList.contains('processed')) {
            return;
        }
        
        row.classList.add('processed');
        processAlert(row);
    }

    async function monitorRows() {
        try {
            const container = await waitForContainerWithRetry('#alerts-container');
            if (!container) {
                console.error("[Content] Could not find alerts container");
                return;
            }

            // Process existing rows
            const existingRows = container.querySelectorAll('tr:not(.processed)');
            existingRows.forEach(processRow);

            // Monitor for new rows
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            if (node.tagName === 'TR') {
                                processRow(node);
                            } else {
                                const newRows = node.querySelectorAll('tr:not(.processed)');
                                newRows.forEach(processRow);
                            }
                        }
                    });
                });
            });

            observer.observe(container, { childList: true, subtree: true });
            console.log("[Content] Row monitoring started");

        } catch (error) {
            console.error("[Content] Error in monitorRows:", error);
        }
    }

    async function waitForContainerWithRetry(selector, maxAttempts = 30, intervalMs = 1000) {
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            const container = document.querySelector(selector);
            if (container) {
                console.log(`[Content] Found container on attempt ${attempt}`);
                return container;
            }
            
            console.log(`[Content] Container not found, attempt ${attempt}/${maxAttempts}`);
            await new Promise(resolve => setTimeout(resolve, intervalMs));
        }
        
        console.error(`[Content] Container not found after ${maxAttempts} attempts`);
        return null;
    }

    function cleanup() {
        // Clean up old processed alerts (older than 1 hour)
        const oneHourAgo = Date.now() - (60 * 60 * 1000);
        for (const [hash, timestamp] of processedAlerts.entries()) {
            if (timestamp < oneHourAgo) {
                processedAlerts.delete(hash);
            }
        }
    }

    function startMonitoring() {
        console.log("[Content] Starting POD monitoring...");
        
        // Setup random refresh
        setupRandomRefresh();
        
        // Start monitoring rows
        monitorRows();
        
        // Cleanup old alerts every 10 minutes
        setInterval(cleanup, 10 * 60 * 1000);
        
        console.log("[Content] POD monitoring started successfully");
    }

    // Firefox-compatible message handling
    browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
        console.log("[Content] Message received:", message);
        
        if (message.action === 'getEventIds') {
            // Extract event IDs from the current page
            const eventIds = [];
            const rows = document.querySelectorAll('#alerts-container tr');
            
            rows.forEach(row => {
                const alertData = extractAlertData(row);
                if (alertData) {
                    // You might need to extract event IDs differently based on your page structure
                    // This is a placeholder implementation
                    eventIds.push(alertData);
                }
            });
            
            sendResponse({ success: true, eventIds: eventIds });
        }
        
        return false; // Synchronous response
    });

    // Start monitoring when the script loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startMonitoring);
    } else {
        startMonitoring();
    }
})();